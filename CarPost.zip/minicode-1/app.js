const AV = require('./utils/av-live-query-weapp-min');

AV.init({
  appId: 'zTGhuU1Nxw3ktVy3yIJxVADz-gzGzoHsz',
  appKey: 'cYhiuLueyUHUuP9QqBLeJ6rV',
  serverURLs: 'https://ztghuu1n.lc-cn-n1-shared.com',
});

App({

})
